package com.yeastar.swebtest.testcase.smokecase.VPN;

import com.yeastar.swebtest.driver.SwebDriver;
import com.yeastar.swebtest.tools.reporter.Logger;
import com.yeastar.swebtest.tools.reporter.Reporter;
import com.yeastar.swebtest.tools.ysassert.YsAssert;
import org.testng.annotations.*;

/**
 * Created by GaGa on 2017-05-26.
 */

public class VPNRunTest extends SwebDriver {
}
