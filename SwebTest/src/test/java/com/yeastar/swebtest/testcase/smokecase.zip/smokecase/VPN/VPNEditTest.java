package com.yeastar.swebtest.testcase.smokecase.VPN;

import com.yeastar.swebtest.driver.SwebDriver;
import com.yeastar.swebtest.tools.reporter.Reporter;
import com.yeastar.swebtest.tools.ysassert.YsAssert;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;

/**
 * Created by GaGa on 2017-05-23.
 */

public class VPNEditTest extends SwebDriver {
}
